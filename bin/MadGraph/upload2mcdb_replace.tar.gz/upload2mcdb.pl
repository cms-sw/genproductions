#!/usr/bin/perl -w
#
$| = 1; # output streams autoflush

use strict;
use warnings;

use HTTP::Request::Common;
use HTTP::Response;
use LWP::UserAgent;
use Crypt::SSLeay;
use Getopt::Long;
use Cwd;
use Fcntl qw(:DEFAULT :flock);
use File::stat;
use File::Basename;

#program version
my $VERSION = "0.2";
#my $MCDB_UPLOAD_SERVER_URL = 'https://mcdb.cern.ch/cgi-bin/authors/upload_server_test.cgi';
my $MCDB_UPLOAD_SERVER_URL = 'https://mcdb.cern.ch/cgi-bin/authors/upload_server.cgi';
my $SRM_SERVER_DEFAULT = "srm-cms.cern.ch";
my @SRM_SERVERS = ("srm-public.cern.ch", "srm-alice.cern.ch", "srm-atlas.cern.ch", "srm-cms.cern.ch", "srm-lhcb.cern.ch", "srm-dteam.cern.ch");
my ($opt_h, $longhelp, $opt_a, $header, $dsname, $verbose, $debug, $replace,
    $not2web, $authors, $category, $descriptiononly, $uploadonly, $artid, $srm_server, $fakepost);

GetOptions (
    "h",                 \$opt_h,         # print out short help
    "help",              \$longhelp,      # print out long help
    "a=s",               \$opt_a,         # set authorization method in MCDB (login, cert, pkcs12, globus)
    "header=s",          \$header,        # set the type of LHEF header (hepml or MG - MadGraph)
    "dsname=s",          \$dsname,        # set DataSetName
    "verbose",           \$verbose,       # be verbose
    "debug",             \$debug,         # be very verbose
    "replace",           \$replace,       # replace description in the article -artid 
                                          # from the header of first file in the argument list
    "not2web",         \$not2web,         # do not post article to the Web (default it is available on the Web)
    "authors=s",       \$authors,         # set additional author names
    "category=s",      \$category,        # set categories for the article
    "descriptiononly", \$descriptiononly, # do not upload any files, create a new article only. 
                                          # information is taken from the header of the first file in the argument list
    "uploadonly",      \$uploadonly,      # upload event files (-artid should be used), do not parse header and create an article
    "artid=s",         \$artid,           # set manually ArticleID to upload files or set description,
    "srmserver=s",     \$srm_server,      # specify SRM access point to use
    "fake",            \$fakepost,        # test/check post information
);

# Print help message
help() if defined $longhelp or $opt_h;
help() unless @ARGV;

#Define authorization method for MCDB: login/password (login); LCG certificate (cert) or PKCS12 LCG certificate (pkcs12);
#please, provide the necessary information below for the corresponding type of authorization

my $session_id  = "";
my $req         = "";
my $ArticleID   = "";
my $GSIPROXY    = "";
my $auth        = $opt_a || "globus";
my $header_type = $header || "MG";
my $fakepostfile = "fakepost.out";

#....RUN main subroutine
eval { &main; };

#....If Errors
if ($@) {print "Error: $@  \n";}
exit;

###############################################################################
sub main {
    my @files = ();

# verbose mode is used
    if (defined $verbose) {
       if (defined $descriptiononly) {
	  print "The description will be defined from the first file:\n"
	} else {
	  print "The following files are going to be uploaded to MCDB and CASTOR:\n"
	}
    }

# ArticleID or DataSetName should be set for -uploadonly
    if ( defined $uploadonly and !( defined $artid or defined $dsname ) ) {
        print "error: in order to use -uploadonly you must specify an article with -artid or -dsname\n";
        exit (1);
    }

# Check whether event files exist and are readable 
    foreach my $file (@ARGV) {
        if ( !-e $file ) {
            print "error: FILE $file does not exist, please, check it. \n";
            exit(1);
        }
        if ( !-r $file ) {
            print "error: FILE $file is not readable, please, check it. \n";
            exit(1);
        }
        push @files, $file;
        print "  $file \n" if defined $verbose;
    }

# Web agent description, necessary in order to send the header of LHEF to MCDB
    my $ua = LWP::UserAgent->new();
    $ua->agent("MCDBUpload/$VERSION");
    $ua->from('$ENV{USER} at $ENV{HOSTNAME}');
    $ua->protocols_allowed( ['https'] );
    my $filebat = $ARGV[0];
    $ENV{HTTPS_VERSION} = 3;
    my @request_form = ();
    my $hepml = "";

# Authorization in MCDB and CASTOR.
# By default grid-proxy-init is used. Other options are valid for MCDB articles only, not for the CASTOR (GRID)
    if ( $auth eq "login" ) {
        my $netloc = "mcdb.cern.ch:443";
        my $realm  = "MCDB login";
        my $uname  = "";             #CERN AFS login name
        my $pass   = "";             #CERN AFS password
        $ua->credentials( $netloc, $realm, $uname => $pass );
    }
    elsif ( $auth eq "pkcs12" ) {
        # CLIENT PKCS12 CERT SUPPORT
        $ENV{HTTPS_PKCS12_FILE}     = '~/.globus/pkcs12.pkcs12';
        $ENV{HTTPS_PKCS12_PASSWORD} = 'PKCS12_PASSWORD';    # you can put here <STDIN> to enter it during the run
    } elsif ( $auth eq "cert" ) {
        $ENV{HTTPS_CERT_FILE} = '~/.globus/usercert.pem';
        $ENV{HTTPS_KEY_FILE}  = '~/.globus/userkey.pem';
    } else {
       my $auth_err = eval { system( "grid-proxy-info", "-e" ); };
       if ($@ || $auth_err) {
          print "No valid proxy found or something is wrong from grid-proxy-info\n $@ $auth_err \n DO NEW AUTHORIZATION!\n";
          system "grid-proxy-init";
	  $auth_err = eval { system( "grid-proxy-info", "-e" ); };
	  if($@ || $auth_err) {
	    print "Still a problem with authorization, please, check it \n $@ $auth_err \n";
	    exit(1);
	  }
       }
       $ENV{HTTPS_CA_DIR} = ( defined $ENV{X509_CERT_DIR} ) ? $ENV{X509_CERT_DIR} : "/etc/grid-security/certificates";
       $GSIPROXY = ( defined $ENV{X509_USER_PROXY} ) ? $ENV{X509_USER_PROXY} : "/tmp/x509up_u$<";
       $ENV{HTTPS_CA_FILE}   = $GSIPROXY;
       $ENV{HTTPS_CERT_FILE} = $GSIPROXY;
       $ENV{HTTPS_KEY_FILE}  = $GSIPROXY;
       $ENV{HTTPS_DEBUG}     = 1 if defined $debug;
    }

# Extract the header from the first LHEF file
    $hepml = extract_hepml_header ($files[0]) if $header_type eq "hepml" and !defined $uploadonly;
    $hepml = extract_madgraph_header ($files[0]) if $header_type eq "MG" and !defined $uploadonly;

# Try to find a previous unfinished uploading session for the same directory
    my @old_sessions = glob("mcdb_upload*.session");
    if ( scalar(@old_sessions) > 0 ) {
        print "error: something is wrong with the previous uploading jobs, there are ",
          $#old_sessions + 1,
          " old sessions in this directory: @old_sessions \n";
        exit (1);
    }
    # elsif( scalar(@old_sessions) == 1 ){
    #  $old_sessions[0] =~ /mcdb_upload_(.*).session/;
    #  $old_session_id = $1;
    #  print "Continue the previous uploading session: $session_id \n";
    #  push @request_form, SESSION => "$old_session_id";
    # }

# Form the HTTP(POST) request to MCDB
    push @request_form, HEPML         => $hepml if $hepml ne "";
    push @request_form, DSNAME        => $dsname if defined $dsname;
    push @request_form, ARTICLEID     => $artid if defined $artid;
    push @request_form, REPLACEHEADER => "1" if defined $replace;
    push @request_form, NOTTOWEB      => "1" if defined $not2web;
    push @request_form, AUTHORS       => $authors if defined $authors;
    push @request_form, CATEGORIES    => $category if defined $category;
    push @request_form, HEPMLTYPE     => $header_type if $hepml ne "";

    print "LHEF Header POST request: \n @request_form \n" if defined $debug;
    if ($fakepost) {
# Fake POST, all information are stored in $fakepostfile. For tests only
      open (INFO, ">$fakepostfile") or die "Can't open $fakepostfile for writing: $!\n";
      print INFO "LHEF Header POST request: \n @request_form \n";
      close INFO;
      exit (0);
    }
    $req = POST $MCDB_UPLOAD_SERVER_URL, \@request_form;

# HTTP(POST) request is being sent to MCDB and ArticleID and CASTOR directory to upload the file are got back 
    my $response = $ua->request($req);
    if ( $response->is_success ) {
        print "Header has been uploaded to MCDB, response content: \n ", $response->as_string(), "\n END of the server response content \n"
          if defined $verbose;
    } else {
        print "error: wrong header in $files[0], uploading to MCDB stopped: ", $response->as_string(), "\n";
        exit (1);
    }

# Parse the MCDB response
    $session_id = $response->header('Sessionid') || "";
    my $import_dir = $response->header('Castordir') || "";
    $ArticleID = $response->header('Articleid') || "";
    my $MCDBDSNAME = $response->header('Mcdbdsname') || "";
    my $MCDB_response = $response->content;

# Check several critical points in the response
    if (($session_id eq "") or ($import_dir eq "") or ($ArticleID eq "")) {
      print "something is wrong on MCDB side, MCDB did not provide session_id: $session_id or castor dir: $import_dir or Article ID: $ArticleID \n";
      exit (1);
    }

    if (defined $dsname and $MCDBDSNAME ne $dsname) {
      print "DataSetName: $MCDBDSNAME returned from MCDB is not equal to the defined by user $dsname for this article $ArticleID The priority is for the ArticleID, not DataSetName. \n";
    }

# Check the old sessions (Not finished yet)
    my $OLD_ARTICLE_ID = "";
    my $OLD_CASTOR_DIR = "";

#    if ( scalar(@old_sessions) == 1 and $session_id ne $old_session_id ) {
    if ( scalar(@old_sessions) == 1 ) {
	$old_sessions[0] =~ /mcdb_upload_(.*).session/;
	my $old_session_id = $1;
	if ($session_id ne $old_session_id) {
    	    print "Old session id $old_session_id does not match the new one $session_id provided by MCDB server \n";
	}
    }

    my $session_file = "mcdb_upload_" . $session_id . ".session";
    my $session_log  = "mcdb_upload_" . $session_id . ".log";
    print "SESSION_FILE: $session_file\n" if defined $verbose;

    sysopen( SESSION_FILE, $session_file, O_CREAT | O_RDWR | O_SYNC )
      or die "Cannot write to $session_file: $!";

    # check for the previous broken session, try to restore it
    if ( scalar(@old_sessions) == 1 ) {
        while (<SESSION_FILE>) {
            if (/ArticleID=\s*(\S*).*/) { $OLD_ARTICLE_ID = $1; }
            if (/CASTORDIR=\s*(\S*).*/) { $OLD_CASTOR_DIR = $1; }

        }
        if ( $OLD_CASTOR_DIR ne $import_dir ) {
            print "Different uploading directories in local old session config and provided from MCDB server, use the last one \n";

        }
        if ( $OLD_ARTICLE_ID ne $ArticleID ) {
            print "Different ArticleID in local old session config and provided from MCDB server, use the last one \n";

        }
    }

    seek( SESSION_FILE, 0, 0 );
    print SESSION_FILE "ArticleID=$ArticleID \n";
    print SESSION_FILE "DataSetName=$MCDBDSNAME \n";
    print SESSION_FILE "CASTORDIR=$import_dir \n";
    print SESSION_FILE $MCDB_response;
    print $MCDB_response if defined $verbose;

# Uploading event files to CASTOR and registration of the files in MCDB
    if ( not defined $descriptiononly ) {
        foreach my $file (@files) {
             eval { &file_upload_grid( $file, $import_dir ); };

# ....If Errors
            if ($@) {
                print SESSION_FILE
                  "!!! ERROR in uploading of file $file to CASTOR: $@ \n";
                print "!!! ERROR in uploading of $file to CASTOR: $@  \n";
                return ($@);
            }

            print SESSION_FILE "File $file has been uploaded to CASTOR \n";
            print "File $file has been uploaded to CASTOR \n"
              if defined $verbose;

	    $hepml = extract_hepml_header( $files[0] )
              if $header_type eq "hepml" and !defined $uploadonly;
            $hepml = extract_madgraph_header( $files[0] )
              if $header_type eq "MG" and !defined $uploadonly;

            my @req_form = ();
            push @req_form,
              (
                ARTICLEID    => $ArticleID || 0,
                UPLOADEDFILE => $file || "",
                SIZE         => ( (stat($file))[7] ) || 0,
                SESSIONID    => $session_id || "",
                CASTORDIR    => $import_dir || "",
              );
            push @req_form,
              (    HEPML => $hepml || "",
                   HEPMLTYPE => $header_type || "",
              ) if $hepml ne "";

            print "File attach request: \n  @req_form\n\n"
               if defined $debug;

            $req = POST $MCDB_UPLOAD_SERVER_URL, \@req_form;
            $response = $ua->request($req);
            if ( $response->is_success ) {
                print SESSION_FILE "File $file has been registered in MCDB: \n", $response->content, "\n";
                print "\nFile $file has been registered in MCDB: \n", $response->content, "\n" if defined $verbose;
            } else {
                print "ERROR during the registration of $file in MCDB: ", $response->as_string(), "\n";
                exit(1);
            }

        }
    }

# Finish the session and post article to the WEB
#    $req = POST 'https://mcdb.cern.ch/cgi-bin/authors/upload_server.cgi', [ Articleid => $ArticleID, POSTARTICLE => "yes" ] ;
#    $response = $ua->request($req);
#    if ($response->is_success) {
#      print SESSION_FILE "Article $ArticleID has been posted to MCDB web page: ",$response->content, "\n";
#      print  "Article $ArticleID has been posted to MCDB web page:  ",$response->content, "\n" if defined $verbose;
#    }else{
#      print "ERROR during the post of $ArticleID to MCDB web page: ",$response->as_string(), "\n";
#      exit(1);
#    }

    close SESSION_FILE;
    system ("mv", "$session_file", "$session_log");
    exit (0);
}

###############################################################################
sub file_upload_grid {
    my $file_to_upload   = shift;
    my $remote_directory = shift;
    print "\n\n$file_to_upload copy to $remote_directory\n";

    eval { system( "grid-proxy-info", "-e" ); };
    if ($@) {
        print "No valid proxy found, do new authorization\n";
        system "grid-proxy-init";
    }

    my $localdir = cwd;

    my $fullname;
    if ( substr( $file_to_upload, 0, 1 ) eq "/" ) {
        $fullname = $file_to_upload;
    }
    else {
        $fullname = cwd() . "/" . $file_to_upload;
    }

    unless ( $srm_server ) {
	$srm_server = $SRM_SERVER_DEFAULT;
	print "Using default SRM server: $srm_server\n";
    } else {
	print "Using user-defined SRM server: $srm_server\n";
    }

    print "Copying $fullname to srm://$srm_server$remote_directory/".basename($fullname)."\n";
    system( "lcg-cp", "file://$fullname","srm://$srm_server$remote_directory/".basename($fullname));

    if ( $? ) { # error while copying file
	print "Error while copying file to Grid location\n",
	      "Possible you should specify appropriate SRM server which can recognize you (e.g., VO-specific)\n",
	      "Suggested servers are: \n",
	      map { "	$_\n" } @SRM_SERVERS,
	      "\n\n";
    }

    #  print "register in local RC\n";
    #  system "globus-job-run lxshare0219.cern.ch /bin/bash -c " .
    #         "\"export GDMP_CONFIG_FILE=/opt/edg/biome/etc/gdmp.conf; " .
    #         "/opt/edg/bin/gdmp_register_local_file -d /flatfiles/SE1/biome\"";

    #print "publish local RC\n";
    #system "globus-job-run lxshare0219.cern.ch /bin/bash -c " .
    #       "\"export GDMP_CONFIG_FILE=/opt/edg/biome/etc/gdmp.conf; " .
    #       "/opt/edg/bin/gdmp_publish_catalogue\"";
}

###############################################################################
sub extract_hepml_header {
    my $file = shift;
    my $string = "";
    my $write  = "0";
    open (BATCH, "<$file") or die "Can't open $file for reading: $!\n";

    while (<BATCH>) {
        if (/<\/header>/) { last; }
        if (/<\/init>/)   { last; }
        if (/<header>/) {
          $write  = "1";
        }
        elsif ($write) {
          $string .= $_;
        }
    }
    close BATCH;

    return $string;
}

###############################################################################
sub extract_madgraph_header {
    my $file = shift;
    my $string = "";
    my $write  = "0";
    open( BATCH, "<$file" ) or die "Can't open $file for reading: $!\n";

    while (<BATCH>) {
        if ( /<LesHouchesEvents/ ... /<\/init>/ ) {
          $string .= $_;
        }
        if (/<\/init>/) { last; }
    }
    close BATCH;

    return $string;
}

###############################################################################
sub help {
    print "Usage:
$0 file1.lhef file2.lhef /scratch/file3.lhef ...
$0 -h                                               # short help
$0 --help                                           # long help
$0 -replace [-artid N] [-dsname DataSetName] files  # replace the description in MCDB 
$0 -descriptiononly                                 # do not upload event files and create a new MCDB article only. 
                                                    # All needed information for the article are taken from the 
                                                    # header of the first evnet file 
$0 -uploadonly [-artid N] [-dsname DataSetName]     # upload new event files to an article defined with -artid or -dsname
 -a [login, pkcs12, cert, globus]                   # type of authorization in MCDB, default is globus
 -srmserver full.host.name                          # define what SRM server should be used to upload files. 
                                                    # default one is $SRM_SERVER_DEFAULT
 -header [MG, hepml]                                # specify a type of the LHEF header (MG - MadGraph, hepml - HepML)
 -dsname DataSetName                                # specify Data Set Name (analog of ArticleID)
 -artid N                                           # specify ArticleID in MCDB (supersede -dsname if they conflicts on MCDB side)
 -authors AFSlogin1, AFSlogin2, ...                 # set additional authors for the article
 -category Category1, Category2, ...                # set MCDB Category where to attache article (default is CMS08MG)
 -not2web                                           # do not post Article to WEB (keep in MCDB), 
                                                    # by default it is posted right after it is created with the script. 
 -verbose                                           # set verbose flag for the session 
 -debug                                             # print out an additional information in the session 
";

  if (defined $longhelp) {
    print "
    The script is a client part of the Automatic Uploadnig Interface of MCDB. 
It parses the header of a LHEF file (in the MadGraph or HepML style) and 
describes the LHEF sample(s) (several files can be processed at onces) in 
MCDB automatically. This interface can upload other types of files as well. 
In this case, it does not send information for a new article, so an existing 
MCDB article should be used for uploading of the event files. It is defined 
via the options -uploadonly [-artid N] [-dsname DataSetName].

    The script extracts the LHEF header of the first file in the argument 
list and POST it to MCDB. MCDB parses the header and create a new article 
in MCDB (or replaces an information in an existing MCDB article with options 
-replace [-artid N] [-dsname DataSetName]). The MCDB server script returns 
ArticleID and PATH to a specific incoming directory where the event samples 
can be upload directly. The script $0 copies the event files to the specific 
CASTOR directory by means of globus-url-copy and, after that, registers the 
files in the MCDB articles. The LHEF header will be parsed to set the 
number of events, cross section, cross section errors, size of the file.
In case this is not LHEF file the header will not be parsed and file will 
not be described automatically. 

!!!! BEGIN: SHOULD BE CHECKED !!!
     Authorization is an important part of any transaction in Internet. So, 
we have implemented several ways of authorization in the script. Two basic 
types are: 
1) CERN AFS login 
2) LCG GRID certificate 
   In order to use the ways, both or one of them, a user should create a 
   new user account in MCDB via New Author Registration (at htpp://mcdb.cern.ch). 
   The default and easiest way to authorize for using the script is to use 
   grid-proxy-init. Besides, this is the only method to upload event samples 
   to CASTOR with this script, AFS login allow user to create new articles only. 
   For the transactions with MCDB (set new article, etc.) several more methods are
   possible: 1) CERN AFS login and passwords      2) PKCS12 LCG certificate 
3) PEM LCG certificate (~/.globus/usercert.pem and ~/.globus/userkey.pem)
4) grid-proxy-init 
!!!! END: SHOULD BE CHECKED !!!

The first three methods require passwords in the run and they are not very 
flexible for the production chain. If you are interested in using non default 
authorizations, please, check/edit corresponding parameters inside the script. 

     Several tasks which are implemented in this interface are described below
with some examples. The identification of the article in MCDB provided by ArticleID,
but it is also possible to identify you article with DataSetName. If you set both
ArticleID and DataSetName, but they are conflict in MCDB (wrong DataSetName for 
this ArticleID) ArticleID is superseded DataSetName and new DataSetName set for this
Article. Please, do not mix files from different physics processes in one 
uploading run, because all of them are described from the header of the 
first file and will be attached to the same article.

1) The main task is to describe a set of LHEF (MadGraph or HepML header) files
in MCDB in a new MCDB article and upload the event files to a specific CASTOR 
directory. 

$0 file1 file2 ...
In this case information for the new MCDB article is taken from the header 
of file1 but all other files will be uploaded and attached to the article. 
Possible options:
  -srmserver full.host.name           # define what SRM server should be used to upload files; 
                                      # default one is $SRM_SERVER_DEFAULT
  -dsname DataSetName                 # specify Data Set Name 
  -header [MG, hepml]                 # specify type of LHEF header (MG - MadGraph, hepml - HepML header)
  -authors AFSlogin1,AFSlogin2,...    # set additional authors for the article
  -category Category1,Category2,...   # set MCDB Category where to attache article (default is CMS08MG)
  -not2web                            # do not post Article to WEB (keep in MCDB), default is post right after it is described
  -verbose                            # be verbose during the run
  -debug                              # print additional information during the session 

2) Upload more samples to an existing MCDB article (the article itself stays unchanged):
$0 [-artid N] [-dsname DataSetName] --uploadonly file1 file2 ... 
Other options:
  -srmserver full.host.name           # define what SRM server should be used to upload files; 
                                      # default one is $SRM_SERVER_DEFAULT
  -verbose                            # set verbose flag for the session
  -debug                              # print out an additional information during the session 

3) Replace information in an existing MCDB article and upload new event files
$0 [-artid N] [-dsname DataSetName] --replace file1 file2 ...
Other options:
  -srmserver full.host.name           # define what SRM server should be used to upload files; 
                                      # default one is $SRM_SERVER_DEFAULT
  -dsname DataSetName                 # specify Data Set Name (analog ArticleID)
  -header [MG, hepml]                 # specify a type of LHEF header (MG - MadGraph, hepml - HepML header)
  -authors AFSlogin1,AFSlogin2,...    # set additional authors for the MCDB article
  -category Category1,Category2,...   # set the MCDB Category for the article (default one is CMS08MG)
  -not2web                            # say do not post the MCDB article to the Web (keep in MCDB), 
                                      # by default the article is available on the Web
  -verbose                            # set verbose flag for the session
  -debug                              # print out an additional information during the session 

4) Describe samples in a new MCDB article, but do not upload any file to CASTOR.
The description is taken from the header of the file 
$0 -descriptiononly file1
Other options: 
  -srmserver full.host.name           # define what SRM server should be used to upload files; 
                                      # default one is $SRM_SERVER_DEFAULT
  -dsname DataSetName                 # specify Data Set Name (analog ArticleID)
  -a [login, pkcs12, cert, globus]    # specify a type of authorization in MCDB, default is globus
  -header [MG, hepml]                 # specify type of LHEF header (MG - MadGraph, hepml - HepML header)
  -authors AFSlogin1,AFSlogin2,...    # set additional authors for the article
  -category Category1,Category2,...   # set MCDB Category where to attache article (default is CMS08MG)
  -not2web                            # do not post Article to WEB (keep in MCDB), default is post right after it is described
  -verbose                            # set verbose flag for the session
  -debug                              # print out an additional information during the session

#     The complete set of options is the following: 
    #[-a login or cert or pkcs12] authorize in MCDB with
    #   AFS login/password or LCG certificate or PKCS12 certificate;
    #   default method is LCG certificate. Necessary paths to certificate
    #   have to be written in the begining of the script $0
    #help();
";

  }

exit(0);
}

__END__

=head1 NAME

Script name - short discription of your program

=head1 SYNOPSIS

 how to us your program

=head1 DESCRIPTION

 long description of your program

=head1 SEE ALSO

 need to know things before somebody uses your program

=head1 AUTHOR

 Lev Dudko

=cut
