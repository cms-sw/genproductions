#!/bin/bash

run () {

    NINJAINSTALLD="$1"
	TARBALLPATH="$2"
    ONELOOPPATH="$3"
    COMPILATIONFLAGS="$4"
	CPPSTANDARDLIB="$5"
	mkdir -p $NINJAINSTALLD
    cd $NINJAINSTALLD
    echo "Decompressing Ninja"
	mkdir Ninja
	tar xzvf ${TARBALLPATH} -C Ninja --strip-components 1
	echo "Entering Ninja directory and installing Ninja"
    cd Ninja
	./configure --prefix=${NINJAINSTALLD} --enable-higher_rank --with-avholo='-L'"${ONELOOPPATH}"' -lavh_olo' FCINCLUDE=-I${ONELOOPPATH} CXX=${CXX} CXXFLAGS="${COMPILATIONFLAGS}" CPPFLAGS='-DNINJA_NO_EXCEPTIONS -fPIC' --enable-quadninja LIBS=${CPPSTANDARDLIB}
	echo "== Content of config.log =="
	cat config.log
	echo "== End of content of config.log =="
	make
	make install
    cd ..
    echo "Finished installing Ninja"
}

run "$@"
