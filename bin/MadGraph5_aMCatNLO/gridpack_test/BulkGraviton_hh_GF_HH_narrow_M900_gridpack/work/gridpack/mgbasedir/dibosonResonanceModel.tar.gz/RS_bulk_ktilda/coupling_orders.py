# This file was automatically created by FeynRules 1.6.13
# Mathematica version: 8.0 for Linux x86 (32-bit) (October 10, 2011)
# Date: Tue 12 Nov 2013 18:05:55


from object_library import all_orders, CouplingOrder


QCD = CouplingOrder(name = 'QCD',
                    expansion_order = 99,
                    hierarchy = 1)

QED = CouplingOrder(name = 'QED',
                    expansion_order = 99,
                    hierarchy = 1)

QTD = CouplingOrder(name = 'QTD',
                    expansion_order = 99,
                    hierarchy = 1)

