# This file was automatically created by FeynRules 2.3.36
# Mathematica version: 11.3.0 for Mac OS X x86 (64-bit) (March 7, 2018)
# Date: Fri 3 Jul 2020 12:34:29


from object_library import all_decays, Decay
import particles as P


Decay_SD = Decay(name = 'Decay_SD',
                 particle = P.SD,
                 partial_widths = {(P.mu__minus__,P.mu__plus__):'((-8*gSDMU**2*MMU**2 + 2*gSDMU**2*MSD**2)*cmath.sqrt(-4*MMU**2*MSD**2 + MSD**4))/(16.*cmath.pi*abs(MSD)**3)'})

Decay_Zd = Decay(name = 'Decay_Zd',
                 particle = P.Zd,
                 partial_widths = {(P.SD__tilde__,P.SD):'((-(gVSD**2*MSD**2) + (gVSD**2*MZd**2)/4.)*cmath.sqrt(-4*MSD**2*MZd**2 + MZd**4))/(48.*cmath.pi*abs(MZd)**3)',
                                   (P.Fd11,P.Fd11):'((-256*gAFd1**2*MFd11**2 + 64*gAFd1**2*MZd**2)*cmath.sqrt(-4*MFd11**2*MZd**2 + MZd**4))/(96.*cmath.pi*abs(MZd)**3)',
                                   (P.Fd11,P.Fd21):'((-8*gAFd11Fd21**2*MFd11**2 - 48*gAFd11Fd21**2*MFd11*MFd21 - 8*gAFd11Fd21**2*MFd21**2 - (8*gAFd11Fd21**2*MFd11**4)/MZd**2 + (16*gAFd11Fd21**2*MFd11**2*MFd21**2)/MZd**2 - (8*gAFd11Fd21**2*MFd21**4)/MZd**2 + 16*gAFd11Fd21**2*MZd**2)*cmath.sqrt(MFd11**4 - 2*MFd11**2*MFd21**2 + MFd21**4 - 2*MFd11**2*MZd**2 - 2*MFd21**2*MZd**2 + MZd**4))/(48.*cmath.pi*abs(MZd)**3)',
                                   (P.d,P.d__tilde__):'(((-17*ca**2*ee**2*eta**2*MD**2)/(6.*cw**2) + (5*ca**2*ee**2*eta**2*MZd**2)/(6.*cw**2) - (17*ca*ee**2*eta*MD**2*sa*sw)/(3.*cw**2) + (5*ca*ee**2*eta*MZd**2*sa*sw)/(3.*cw**2) - (17*ee**2*MD**2*sa**2*sw**2)/(6.*cw**2) + (5*ee**2*MZd**2*sa**2*sw**2)/(6.*cw**2))*cmath.sqrt(-4*MD**2*MZd**2 + MZd**4))/(48.*cmath.pi*abs(MZd)**3)',
                                   (P.s,P.s__tilde__):'(((-17*ca**2*ee**2*eta**2*MS**2)/(6.*cw**2) + (5*ca**2*ee**2*eta**2*MZd**2)/(6.*cw**2) - (17*ca*ee**2*eta*MS**2*sa*sw)/(3.*cw**2) + (5*ca*ee**2*eta*MZd**2*sa*sw)/(3.*cw**2) - (17*ee**2*MS**2*sa**2*sw**2)/(6.*cw**2) + (5*ee**2*MZd**2*sa**2*sw**2)/(6.*cw**2))*cmath.sqrt(-4*MS**2*MZd**2 + MZd**4))/(48.*cmath.pi*abs(MZd)**3)',
                                   (P.b,P.b__tilde__):'(((-17*ca**2*ee**2*eta**2*MB**2)/(6.*cw**2) + (5*ca**2*ee**2*eta**2*MZd**2)/(6.*cw**2) - (17*ca*ee**2*eta*MB**2*sa*sw)/(3.*cw**2) + (5*ca*ee**2*eta*MZd**2*sa*sw)/(3.*cw**2) - (17*ee**2*MB**2*sa**2*sw**2)/(6.*cw**2) + (5*ee**2*MZd**2*sa**2*sw**2)/(6.*cw**2))*cmath.sqrt(-4*MB**2*MZd**2 + MZd**4))/(48.*cmath.pi*abs(MZd)**3)',
                                   (P.e__minus__,P.e__plus__):'(((7*ca**2*ee**2*eta**2*Me**2)/(2.*cw**2) + (5*ca**2*ee**2*eta**2*MZd**2)/(2.*cw**2) + (7*ca*ee**2*eta*Me**2*sa*sw)/cw**2 + (5*ca*ee**2*eta*MZd**2*sa*sw)/cw**2 + (7*ee**2*Me**2*sa**2*sw**2)/(2.*cw**2) + (5*ee**2*MZd**2*sa**2*sw**2)/(2.*cw**2))*cmath.sqrt(-4*Me**2*MZd**2 + MZd**4))/(48.*cmath.pi*abs(MZd)**3)',
                                   (P.mu__minus__,P.mu__plus__):'(((7*ca**2*ee**2*eta**2*MMU**2)/(2.*cw**2) + (5*ca**2*ee**2*eta**2*MZd**2)/(2.*cw**2) + (7*ca*ee**2*eta*MMU**2*sa*sw)/cw**2 + (5*ca*ee**2*eta*MZd**2*sa*sw)/cw**2 + (7*ee**2*MMU**2*sa**2*sw**2)/(2.*cw**2) + (5*ee**2*MZd**2*sa**2*sw**2)/(2.*cw**2))*cmath.sqrt(-4*MMU**2*MZd**2 + MZd**4))/(48.*cmath.pi*abs(MZd)**3)',
                                   (P.ta__minus__,P.ta__plus__):'(((7*ca**2*ee**2*eta**2*MTA**2)/(2.*cw**2) + (5*ca**2*ee**2*eta**2*MZd**2)/(2.*cw**2) + (7*ca*ee**2*eta*MTA**2*sa*sw)/cw**2 + (5*ca*ee**2*eta*MZd**2*sa*sw)/cw**2 + (7*ee**2*MTA**2*sa**2*sw**2)/(2.*cw**2) + (5*ee**2*MZd**2*sa**2*sw**2)/(2.*cw**2))*cmath.sqrt(-4*MTA**2*MZd**2 + MZd**4))/(48.*cmath.pi*abs(MZd)**3)',
                                   (P.u,P.u__tilde__):'(((7*ca**2*ee**2*eta**2*MU**2)/(6.*cw**2) + (17*ca**2*ee**2*eta**2*MZd**2)/(6.*cw**2) + (7*ca*ee**2*eta*MU**2*sa*sw)/(3.*cw**2) + (17*ca*ee**2*eta*MZd**2*sa*sw)/(3.*cw**2) + (7*ee**2*MU**2*sa**2*sw**2)/(6.*cw**2) + (17*ee**2*MZd**2*sa**2*sw**2)/(6.*cw**2))*cmath.sqrt(-4*MU**2*MZd**2 + MZd**4))/(48.*cmath.pi*abs(MZd)**3)',
                                   (P.c,P.c__tilde__):'(((7*ca**2*ee**2*eta**2*MC**2)/(6.*cw**2) + (17*ca**2*ee**2*eta**2*MZd**2)/(6.*cw**2) + (7*ca*ee**2*eta*MC**2*sa*sw)/(3.*cw**2) + (17*ca*ee**2*eta*MZd**2*sa*sw)/(3.*cw**2) + (7*ee**2*MC**2*sa**2*sw**2)/(6.*cw**2) + (17*ee**2*MZd**2*sa**2*sw**2)/(6.*cw**2))*cmath.sqrt(-4*MC**2*MZd**2 + MZd**4))/(48.*cmath.pi*abs(MZd)**3)',
                                   (P.t,P.t__tilde__):'(((7*ca**2*ee**2*eta**2*MT**2)/(6.*cw**2) + (17*ca**2*ee**2*eta**2*MZd**2)/(6.*cw**2) + (7*ca*ee**2*eta*MT**2*sa*sw)/(3.*cw**2) + (17*ca*ee**2*eta*MZd**2*sa*sw)/(3.*cw**2) + (7*ee**2*MT**2*sa**2*sw**2)/(6.*cw**2) + (17*ee**2*MZd**2*sa**2*sw**2)/(6.*cw**2))*cmath.sqrt(-4*MT**2*MZd**2 + MZd**4))/(48.*cmath.pi*abs(MZd)**3)',
                                   (P.ve,P.ve__tilde__):'(MZd**2*((ca**2*ee**2*eta**2*MZd**2)/(2.*cw**2) + (ca*ee**2*eta*MZd**2*sa*sw)/cw**2 + (ee**2*MZd**2*sa**2*sw**2)/(2.*cw**2)))/(48.*cmath.pi*abs(MZd)**3)',
                                   (P.vm,P.vm__tilde__):'(MZd**2*((ca**2*ee**2*eta**2*MZd**2)/(2.*cw**2) + (ca*ee**2*eta*MZd**2*sa*sw)/cw**2 + (ee**2*MZd**2*sa**2*sw**2)/(2.*cw**2)))/(48.*cmath.pi*abs(MZd)**3)',
                                   (P.vt,P.vt__tilde__):'(MZd**2*((ca**2*ee**2*eta**2*MZd**2)/(2.*cw**2) + (ca*ee**2*eta*MZd**2*sa*sw)/cw**2 + (ee**2*MZd**2*sa**2*sw**2)/(2.*cw**2)))/(48.*cmath.pi*abs(MZd)**3)'})

Decay_Fd11 = Decay(name = 'Decay_Fd11',
                   particle = P.Fd11,
                   partial_widths = {(P.Zd,P.Fd21):'((8*gAFd11Fd21**2*MFd11**2 + 48*gAFd11Fd21**2*MFd11*MFd21 + 8*gAFd11Fd21**2*MFd21**2 + (8*gAFd11Fd21**2*MFd11**4)/MZd**2 - (16*gAFd11Fd21**2*MFd11**2*MFd21**2)/MZd**2 + (8*gAFd11Fd21**2*MFd21**4)/MZd**2 - 16*gAFd11Fd21**2*MZd**2)*cmath.sqrt(MFd11**4 - 2*MFd11**2*MFd21**2 + MFd21**4 - 2*MFd11**2*MZd**2 - 2*MFd21**2*MZd**2 + MZd**4))/(32.*cmath.pi*abs(MFd11)**3)'})

Decay_Fd21 = Decay(name = 'Decay_Fd21',
                   particle = P.Fd21,
                   partial_widths = {(P.Zd,P.Fd11):'((8*gAFd11Fd21**2*MFd11**2 + 48*gAFd11Fd21**2*MFd11*MFd21 + 8*gAFd11Fd21**2*MFd21**2 + (8*gAFd11Fd21**2*MFd11**4)/MZd**2 - (16*gAFd11Fd21**2*MFd11**2*MFd21**2)/MZd**2 + (8*gAFd11Fd21**2*MFd21**4)/MZd**2 - 16*gAFd11Fd21**2*MZd**2)*cmath.sqrt(MFd11**4 - 2*MFd11**2*MFd21**2 + MFd21**4 - 2*MFd11**2*MZd**2 - 2*MFd21**2*MZd**2 + MZd**4))/(32.*cmath.pi*abs(MFd21)**3)'})

Decay_Z = Decay(name = 'Decay_Z',
                particle = P.Z,
                partial_widths = {(P.d,P.d__tilde__):'(((-17*ee**2*eta**2*MD**2*sa**2)/(6.*cw**2) + (5*ee**2*eta**2*MZ**2*sa**2)/(6.*cw**2) + (17*ca*ee**2*eta*MD**2*sa*sw)/(3.*cw**2) - (5*ca*ee**2*eta*MZ**2*sa*sw)/(3.*cw**2) - (17*ca**2*ee**2*MD**2*sw**2)/(6.*cw**2) + (5*ca**2*ee**2*MZ**2*sw**2)/(6.*cw**2))*cmath.sqrt(-4*MD**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.s,P.s__tilde__):'(((-17*ee**2*eta**2*MS**2*sa**2)/(6.*cw**2) + (5*ee**2*eta**2*MZ**2*sa**2)/(6.*cw**2) + (17*ca*ee**2*eta*MS**2*sa*sw)/(3.*cw**2) - (5*ca*ee**2*eta*MZ**2*sa*sw)/(3.*cw**2) - (17*ca**2*ee**2*MS**2*sw**2)/(6.*cw**2) + (5*ca**2*ee**2*MZ**2*sw**2)/(6.*cw**2))*cmath.sqrt(-4*MS**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.b,P.b__tilde__):'(((-17*ee**2*eta**2*MB**2*sa**2)/(6.*cw**2) + (5*ee**2*eta**2*MZ**2*sa**2)/(6.*cw**2) + (17*ca*ee**2*eta*MB**2*sa*sw)/(3.*cw**2) - (5*ca*ee**2*eta*MZ**2*sa*sw)/(3.*cw**2) - (17*ca**2*ee**2*MB**2*sw**2)/(6.*cw**2) + (5*ca**2*ee**2*MZ**2*sw**2)/(6.*cw**2))*cmath.sqrt(-4*MB**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.e__minus__,P.e__plus__):'(((7*ee**2*eta**2*Me**2*sa**2)/(2.*cw**2) + (5*ee**2*eta**2*MZ**2*sa**2)/(2.*cw**2) - (7*ca*ee**2*eta*Me**2*sa*sw)/cw**2 - (5*ca*ee**2*eta*MZ**2*sa*sw)/cw**2 + (7*ca**2*ee**2*Me**2*sw**2)/(2.*cw**2) + (5*ca**2*ee**2*MZ**2*sw**2)/(2.*cw**2))*cmath.sqrt(-4*Me**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.mu__minus__,P.mu__plus__):'(((7*ee**2*eta**2*MMU**2*sa**2)/(2.*cw**2) + (5*ee**2*eta**2*MZ**2*sa**2)/(2.*cw**2) - (7*ca*ee**2*eta*MMU**2*sa*sw)/cw**2 - (5*ca*ee**2*eta*MZ**2*sa*sw)/cw**2 + (7*ca**2*ee**2*MMU**2*sw**2)/(2.*cw**2) + (5*ca**2*ee**2*MZ**2*sw**2)/(2.*cw**2))*cmath.sqrt(-4*MMU**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.ta__minus__,P.ta__plus__):'(((7*ee**2*eta**2*MTA**2*sa**2)/(2.*cw**2) + (5*ee**2*eta**2*MZ**2*sa**2)/(2.*cw**2) - (7*ca*ee**2*eta*MTA**2*sa*sw)/cw**2 - (5*ca*ee**2*eta*MZ**2*sa*sw)/cw**2 + (7*ca**2*ee**2*MTA**2*sw**2)/(2.*cw**2) + (5*ca**2*ee**2*MZ**2*sw**2)/(2.*cw**2))*cmath.sqrt(-4*MTA**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.u,P.u__tilde__):'(((7*ee**2*eta**2*MU**2*sa**2)/(6.*cw**2) + (17*ee**2*eta**2*MZ**2*sa**2)/(6.*cw**2) - (7*ca*ee**2*eta*MU**2*sa*sw)/(3.*cw**2) - (17*ca*ee**2*eta*MZ**2*sa*sw)/(3.*cw**2) + (7*ca**2*ee**2*MU**2*sw**2)/(6.*cw**2) + (17*ca**2*ee**2*MZ**2*sw**2)/(6.*cw**2))*cmath.sqrt(-4*MU**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.c,P.c__tilde__):'(((7*ee**2*eta**2*MC**2*sa**2)/(6.*cw**2) + (17*ee**2*eta**2*MZ**2*sa**2)/(6.*cw**2) - (7*ca*ee**2*eta*MC**2*sa*sw)/(3.*cw**2) - (17*ca*ee**2*eta*MZ**2*sa*sw)/(3.*cw**2) + (7*ca**2*ee**2*MC**2*sw**2)/(6.*cw**2) + (17*ca**2*ee**2*MZ**2*sw**2)/(6.*cw**2))*cmath.sqrt(-4*MC**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.t,P.t__tilde__):'(((7*ee**2*eta**2*MT**2*sa**2)/(6.*cw**2) + (17*ee**2*eta**2*MZ**2*sa**2)/(6.*cw**2) - (7*ca*ee**2*eta*MT**2*sa*sw)/(3.*cw**2) - (17*ca*ee**2*eta*MZ**2*sa*sw)/(3.*cw**2) + (7*ca**2*ee**2*MT**2*sw**2)/(6.*cw**2) + (17*ca**2*ee**2*MZ**2*sw**2)/(6.*cw**2))*cmath.sqrt(-4*MT**2*MZ**2 + MZ**4))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.ve,P.ve__tilde__):'(MZ**2*((ee**2*eta**2*MZ**2*sa**2)/(2.*cw**2) - (ca*ee**2*eta*MZ**2*sa*sw)/cw**2 + (ca**2*ee**2*MZ**2*sw**2)/(2.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.vm,P.vm__tilde__):'(MZ**2*((ee**2*eta**2*MZ**2*sa**2)/(2.*cw**2) - (ca*ee**2*eta*MZ**2*sa*sw)/cw**2 + (ca**2*ee**2*MZ**2*sw**2)/(2.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)',
                                  (P.vt,P.vt__tilde__):'(MZ**2*((ee**2*eta**2*MZ**2*sa**2)/(2.*cw**2) - (ca*ee**2*eta*MZ**2*sa*sw)/cw**2 + (ca**2*ee**2*MZ**2*sw**2)/(2.*cw**2)))/(48.*cmath.pi*abs(MZ)**3)'})

